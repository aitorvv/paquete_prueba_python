def dbh_promedio(dbh_1, dbh_2):
    return (dbh_1 + dbh_2)/2